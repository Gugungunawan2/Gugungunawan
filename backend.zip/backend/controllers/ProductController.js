import Product from "../models/ProductModel.js";

export const getProducts = (req,res)=>{
    
}
export const getProductById = (req,res)=>{

}
export const saveProduct = (req,res)=>{

}
export const updateProduct = (req,res)=>{

}
export const deletProduct = (req,res)=>{

}